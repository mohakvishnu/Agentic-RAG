import os, io, logging, time
from datetime import datetime
from typing import List, Dict, Any
from fastapi import FastAPI, Body, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
from retriever import Retriever
from agents import Memory, Policy, Route, answer_rag, answer_code, answer_sql
from pypdf import PdfReader
from docx import Document

# Configure logging
log_dir = "logs"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'{log_dir}/api_{datetime.now().strftime("%Y%m%d")}.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

load_dotenv()
CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")]

app = FastAPI(title="Agentic RAG (Lite) — Hybrid + RRF")
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

retriever = Retriever()
memory = Memory()
logger.info("Initialized Retriever and Memory services")
logger.info("=== API Server Starting ===")
logger.info(f"CORS Origins: {CORS_ORIGINS}")

class AskRequest(BaseModel):
    query: str
    session_id: str = "default"

class AskResponse(BaseModel):
    answer: str
    citations: List[Dict[str, Any]] = []
    route: str

@app.get("/health")
def health():
    logger.debug("Health check requested")
    return {"status": "ok"}

# ---------- Text ingestion (quick) ----------
@app.post("/ingest")
def ingest(text: str = Body(..., embed=True)):
    logger.info("Processing text ingestion request")
    logger.debug(f"Text length: {len(text)} chars")
    try:
        n = retriever.add_texts([text], metadatas=[{"source": "api"}])
        logger.info(f"Successfully ingested {n} documents")
        return {"added": n}
    except Exception as e:
        logger.error(f"Ingestion failed: {str(e)}", exc_info=True)
        raise

# ---------- File upload & ingestion ----------
@app.post("/upload")
async def upload(files: List[UploadFile] = File(...)):
    logger.info(f"Processing upload request for {len(files)} files")
    texts, metas = [], []
    
    for f in files:
        start_time = time.time()
        name = f.filename or "file"
        logger.info(f"Processing file: {name}")
        
        try:
            content = await f.read()
            ext = (name.split(".")[-1] or "").lower()
            logger.debug(f"File type: {ext}, size: {len(content)} bytes")

            if ext in ("txt", "md", "csv", "log"):
                text = content.decode("utf-8", errors="ignore")
                texts.append(text)
                metas.append({"source": name})
                logger.debug(f"Processed text file: {len(text)} chars")
            elif ext in ("pdf",):
                reader = PdfReader(io.BytesIO(content))
                pages = [p.extract_text() or "" for p in reader.pages]
                text = "\n".join(pages)
                texts.append(text)
                metas.append({"source": name})
                logger.debug(f"Processed PDF: {len(pages)} pages")
            elif ext in ("docx",):
                doc = Document(io.BytesIO(content))
                text = "\n".join([p.text for p in doc.paragraphs])
                texts.append(text)
                metas.append({"source": name})
                logger.debug(f"Processed DOCX: {len(text)} chars")
            else:
                logger.warning(f"Unsupported file type: {ext}")
                metas.append({"source": name, "skipped": True})
                
            duration = time.time() - start_time
            logger.info(f"Processed {name} in {duration:.2f}s")
        except Exception as e:
            logger.error(f"Failed to process {name}: {str(e)}", exc_info=True)
            metas.append({"source": name, "error": str(e)})

    pairs = [(t, m) for t, m in zip(texts, metas) if t and not m.get("skipped")]
    if pairs:
        logger.info(f"Ingesting {len(pairs)} processed documents")
        n = retriever.add_texts([p[0] for p in pairs], metadatas=[p[1] for p in pairs])
    else:
        n = 0
        logger.warning("No valid documents to ingest")
    
    return {"uploaded": len(files), "ingested": n, "metas": metas}

# ---------- Ask: hybrid + RRF ----------
@app.post("/ask", response_model=AskResponse)
def ask(payload: AskRequest):
    req_id = f"req_{int(time.time())}"
    logger.info(f"[{req_id}] Processing ask request for session: {payload.session_id}")
    logger.debug(f"[{req_id}] Query: {payload.query}")
    
    try:
        start_time = time.time()
        docs = retriever.hybrid_search(payload.query, k_dense=6, k_sparse=6, k_rrf=60, top_k=6)
        logger.debug(f"[{req_id}] Retrieved {len(docs)} documents")
        
        context = "\n\n".join(d["text"] for d in docs)
        citations = [{"doc_id": d["id"], "meta": d.get("meta", {}), "rrf": d.get("_rrf")} for d in docs]
        
        route = Policy.decide(payload.query)
        logger.info(f"[{req_id}] Selected route: {route.value}")
        
        if route == Route.CODE:
            answer = answer_code(payload.query, context)
        elif route == Route.SQL:
            answer = answer_sql(payload.query)
        else:
            answer = answer_rag(payload.query, context)
            
        memory.save(payload.session_id, payload.query, answer, citations)
        
        duration = time.time() - start_time
        logger.info(f"[{req_id}] Request completed in {duration:.2f}s")
        
        return AskResponse(answer=answer, citations=citations, route=route.value)
    except Exception as e:
        logger.error(f"[{req_id}] Request failed: {str(e)}", exc_info=True)
        raise
