import os, re, sqlite3, uuid
import logging
from datetime import datetime
from dotenv import load_dotenv
from typing import List, Dict, Any, Tuple
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
from rank_bm25 import BM25Okapi

# Configure logging
log_dir = "logs"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'{log_dir}/retriever_{datetime.now().strftime("%Y%m%d")}.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

load_dotenv()
CHROMA_DIR = os.getenv("CHROMA_DIR", ".chroma")
EMBED_MODEL = os.getenv("EMBED_MODEL", "intfloat/e5-base-v2")
SQLITE_PATH = os.getenv("SQLITE_PATH", "./rag_memory.db")

_word_re = re.compile(r"[A-Za-z0-9_]+")

def tokenize(text: str) -> List[str]:
    return [t.lower() for t in _word_re.findall(text or "")]

class Retriever:
    """
    Dense store: Chroma
    Sparse store: SQLite (table: docs) + in-Python BM25 over tokens
    Hybrid search: dense top-k + BM25 top-k → RRF
    """
    def __init__(self, collection: str = "rag_docs"):
        logger.info(f"Initializing Retriever with collection: {collection}")
        try:
            self.client = chromadb.PersistentClient(path=CHROMA_DIR, settings=Settings(allow_reset=True))
            self.col = self.client.get_or_create_collection(collection, metadata={"hnsw:space": "cosine"})
            logger.info(f"Connected to Chroma collection: {collection}")
            
            self.encoder = SentenceTransformer(EMBED_MODEL)
            logger.info(f"Initialized SentenceTransformer with model: {EMBED_MODEL}")
            
            self.conn = sqlite3.connect(SQLITE_PATH, check_same_thread=False)
            logger.info(f"Connected to SQLite database: {SQLITE_PATH}")
            
            self._ensure_sqlite()
        except Exception as e:
            logger.error(f"Failed to initialize Retriever: {str(e)}", exc_info=True)
            raise

    # ---------- SQLite (sparse) ----------
    def _ensure_sqlite(self):
        logger.debug("Ensuring SQLite table exists")
        try:
            cur = self.conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS docs(
                    id TEXT PRIMARY KEY,
                    text TEXT,
                    source TEXT
                )
            """)
            self.conn.commit()
            logger.info("SQLite table 'docs' verified/created successfully")
        except Exception as e:
            logger.error(f"Failed to ensure SQLite table: {str(e)}", exc_info=True)
            raise

    def _sqlite_add(self, pairs: List[Tuple[str, str, str | None]]):
        logger.debug(f"Adding {len(pairs)} documents to SQLite")
        try:
            cur = self.conn.cursor()
            cur.executemany("INSERT OR REPLACE INTO docs(id, text, source) VALUES(?,?,?)", pairs)
            self.conn.commit()
            logger.info(f"Successfully inserted {len(pairs)} documents into SQLite")
        except Exception as e:
            logger.error(f"Failed to add documents to SQLite: {str(e)}", exc_info=True)
            raise

    def _sqlite_all_docs(self) -> List[Dict[str, Any]]:
        logger.debug("Retrieving all documents from SQLite")
        try:
            cur = self.conn.cursor()
            cur.execute("SELECT id, text, source FROM docs")
            rows = cur.fetchall()
            logger.info(f"Retrieved {len(rows)} documents from SQLite")
            return [{"id": r[0], "text": r[1], "meta": {"source": r[2]} if r[2] else {}} for r in rows]
        except Exception as e:
            logger.error(f"Failed to retrieve documents from SQLite: {str(e)}", exc_info=True)
            raise

    # ---------- Dense add/search ----------
    def add_texts(self, texts: List[str], metadatas: List[Dict[str, Any]] | None = None, ids: List[str] | None = None) -> int:
        logger.info(f"Adding {len(texts)} texts to retriever")
        try:
            if not texts:
                logger.warning("No texts provided to add")
                return 0
                
            if ids is None:
                ids = [str(uuid.uuid4()) for _ in texts]
                logger.debug(f"Generated {len(ids)} new UUIDs")
                
            if metadatas is None:
                metadatas = [{} for _ in texts]

            logger.debug("Encoding texts with SentenceTransformer")
            vecs = self.encoder.encode(texts, normalize_embeddings=True).tolist()
            
            logger.debug("Adding documents to Chroma")
            self.col.add(documents=texts, embeddings=vecs, metadatas=metadatas, ids=ids)
            
            pairs = [(ids[i], texts[i], metadatas[i].get("source")) for i in range(len(texts))]
            self._sqlite_add(pairs)
            
            logger.info(f"Successfully added {len(texts)} documents to both stores")
            return len(texts)
        except Exception as e:
            logger.error(f"Failed to add texts: {str(e)}", exc_info=True)
            raise

    def search_dense(self, query: str, k: int = 6) -> List[Dict[str, Any]]:
        logger.info(f"Performing dense search with query: '{query}', k={k}")
        try:
            logger.debug("Encoding query")
            q_emb = self.encoder.encode([f"query: {query}"], normalize_embeddings=True).tolist()[0]
            
            logger.debug("Querying Chroma")
            res = self.col.query(query_embeddings=[q_emb], n_results=k)
            
            out: List[Dict[str, Any]] = []
            ids = res.get("ids", [[]])[0]
            docs = res.get("documents", [[]])[0]
            metas = res.get("metadatas", [[]])[0] if res.get("metadatas") else [{} for _ in ids]
            
            logger.info(f"Dense search returned {len(ids)} results")
            return [{"id": ids[i], "text": docs[i], "meta": metas[i]} for i in range(len(ids))]
        except Exception as e:
            logger.error(f"Dense search failed: {str(e)}", exc_info=True)
            raise

    # ---------- BM25 over SQLite ----------
    def search_bm25(self, query: str, k: int = 6) -> List[Dict[str, Any]]:
        logger.info(f"Performing BM25 search with query: '{query}', k={k}")
        try:
            docs = self._sqlite_all_docs()
            if not docs:
                logger.warning("No documents found for BM25 search")
                return []
                
            logger.debug("Tokenizing corpus and query")
            corpus_tokens = [tokenize(d["text"]) for d in docs]
            q_tokens = tokenize(query)
            
            logger.debug("Computing BM25 scores")
            bm25 = BM25Okapi(corpus_tokens)
            scores = bm25.get_scores(q_tokens)
            
            ranked = sorted(zip(docs, scores), key=lambda x: x[1], reverse=True)[:k]
            logger.info(f"BM25 search returned {len(ranked)} results")
            return [r[0] | {"_bm25": float(r[1])} for r in ranked]
        except Exception as e:
            logger.error(f"BM25 search failed: {str(e)}", exc_info=True)
            raise

    # ---------- RRF fusion ----------
    @staticmethod
    def _rrf(dense_list: List[Dict[str, Any]], sparse_list: List[Dict[str, Any]], k: int = 60) -> List[Dict[str, Any]]:
        """
        Reciprocal Rank Fusion:
          score(doc) = sum(1 / (k + rank_i))
        """
        fused: Dict[str, Dict[str, Any]] = {}
        # Map ranks
        for rank, d in enumerate(dense_list, start=1):
            fused.setdefault(d["id"], d | {"_rrf": 0.0, "_dense_rank": rank})
            fused[d["id"]]["_rrf"] += 1.0 / (k + rank)
        for rank, d in enumerate(sparse_list, start=1):
            fused.setdefault(d["id"], d | {"_rrf": 0.0, "_sparse_rank": rank})
            fused[d["id"]]["_rrf"] += 1.0 / (k + rank)

        # Make sure text/meta are present (prefer dense text if collision)
        merged = list(fused.values())
        merged.sort(key=lambda x: x["_rrf"], reverse=True)
        return merged

    def hybrid_search(self, query: str, k_dense: int = 6, k_sparse: int = 6, k_rrf: int = 60, top_k: int = 6) -> List[Dict[str, Any]]:
        logger.info(f"Performing hybrid search with query: '{query}', k_dense={k_dense}, k_sparse={k_sparse}, top_k={top_k}")
        try:
            dense = self.search_dense(query, k_dense)
            sparse = self.search_bm25(query, k_sparse)
            
            logger.debug("Performing RRF fusion")
            fused = self._rrf(dense, sparse, k=k_rrf)
            
            logger.info(f"Hybrid search returning top {top_k} results")
            return fused[:top_k]
        except Exception as e:
            logger.error(f"Hybrid search failed: {str(e)}", exc_info=True)
            raise
