const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8000";

export async function ask(query, sessionId = "demo") {
  const r = await fetch(`${API_BASE}/ask`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, session_id: sessionId })
  });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

export async function ingest(text) {
  const r = await fetch(`${API_BASE}/ingest`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(text)
  });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

export async function uploadFiles(files) {
  const fd = new FormData();
  for (const f of files) fd.append("files", f);
  const r = await fetch(`${API_BASE}/upload`, {
    method: "POST",
    body: fd
  });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}
