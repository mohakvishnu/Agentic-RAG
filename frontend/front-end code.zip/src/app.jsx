import React, { useState, useRef } from "react"
import { ask, ingest, uploadFiles } from "./api"

export default function App() {
  const [q, setQ] = useState("")
  const [log, setLog] = useState([])
  const [busy, setBusy] = useState(false)
  const [uploadInfo, setUploadInfo] = useState(null)
  const fileRef = useRef(null)

  async function onAsk(e) {
    e.preventDefault()
    if (!q.trim()) return
    setBusy(true)
    try {
      const res = await ask(q)
      setLog(l => [{ role: "user", text: q }, { role: "assistant", ...res }, ...l])
      setQ("")
    } catch (err) {
      alert(err.message)
    } finally {
      setBusy(false)
    }
  }

  async function seed() {
    const text = prompt("Paste text to ingest:", "Agentic RAG is awesome.")
    if (!text) return
    try {
      await ingest(text)
      alert("Ingested!")
    } catch (e) { alert(e.message) }
  }

  async function onUpload() {
    const files = fileRef.current?.files
    if (!files || !files.length) return alert("Choose file(s) first.")
    try {
      const res = await uploadFiles(files)
      setUploadInfo(res)
      alert(`Uploaded: ${res.uploaded}, Ingested: ${res.ingested}`)
      fileRef.current.value = ""
    } catch (e) {
      alert(e.message)
    }
  }

  return (
    <div style={{ maxWidth: 920, margin: "40px auto", fontFamily: "Inter, system-ui, Arial" }}>
      <h1>Agentic RAG (Lite) — Hybrid + RRF</h1>
      <p style={{ color: "#555" }}>
        Upload TXT/PDF/DOCX → ingested into dense (Chroma) and sparse (SQLite). Queries use BM25 + dense with RRF fusion.
      </p>

      <section style={{ marginBottom: 16, padding: 16, border: "1px solid #eee", borderRadius: 12 }}>
        <h3 style={{ marginTop: 0 }}>Upload files</h3>
        <input ref={fileRef} multiple type="file" accept=".txt,.md,.csv,.log,.pdf,.docx" />
        <button onClick={onUpload} style={{ marginLeft: 8, padding: "8px 12px", borderRadius: 8 }}>
          Upload & Ingest
        </button>
        {uploadInfo ? (
          <details style={{ marginTop: 8 }}>
            <summary>Last upload details</summary>
            <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(uploadInfo, null, 2)}</pre>
          </details>
        ) : null}
      </section>

      <form onSubmit={onAsk} style={{ display: "flex", gap: 8 }}>
        <input
          value={q}
          onChange={e => setQ(e.target.value)}
          placeholder="Ask anything… e.g., “Summarize the PDFs I uploaded”, “Show last 5 memories (SQL)”"
          style={{ flex: 1, padding: 12, borderRadius: 8, border: "1px solid #ddd" }}
        />
        <button disabled={busy} style={{ padding: "12px 16px", borderRadius: 8 }}>Ask</button>
        <button type="button" onClick={seed} style={{ padding: "12px 16px", borderRadius: 8 }}>Ingest</button>
      </form>

      <div style={{ marginTop: 24, display: "grid", gap: 16 }}>
        {log.map((m, i) => (
          <div key={i} style={{
            border: "1px solid #eee", borderRadius: 12, padding: 16,
            background: m.role === "user" ? "#fffdf5" : "#f7fbff"
          }}>
            {m.role === "user" ? (
              <>
                <div style={{ fontWeight: 600, marginBottom: 6 }}>You</div>
                <div>{m.text}</div>
              </>
            ) : (
              <>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <div style={{ fontWeight: 600 }}>Assistant</div>
                  <span style={{
                    fontSize: 12,
                    background: "#eef", padding: "2px 8px", borderRadius: 999
                  }}>{m.route}</span>
                </div>
                <pre style={{ whiteSpace: "pre-wrap" }}>{m.answer}</pre>
                {m.citations?.length ? (
                  <details style={{ marginTop: 8 }}>
                    <summary>Citations</summary>
                    <ul>
                      {m.citations.map((c, idx) => (
                        <li key={idx}>
                          <code>{c.doc_id}</code>
                          {" "}{c.meta?.source ? `— ${c.meta.source}` : ""}
                          {typeof c.rrf === "number" ? <> — RRF: {c.rrf.toFixed(4)}</> : null}
                        </li>
                      ))}
                    </ul>
                  </details>
                ) : null}
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
